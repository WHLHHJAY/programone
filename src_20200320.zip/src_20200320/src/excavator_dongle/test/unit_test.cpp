#include <iostream>

#include "ros/ros.h"
#include "bucket_info.h"
#include "server_info.h"
#include "excavator_dongle/actual_angle_1300.h"
#include "counter.hpp"
#include "backhoe_dongle.hpp"
#include "nav_msgs/Odometry.h"

int main(int argc, char** argv){
    ros::init(argc, argv, "fake_sensor");
    ros::NodeHandle n;
    ros::Rate loop_rate(1);
    ros::Publisher angle_pub = n.advertise<excavator_dongle::actual_angle_1300>("/actual_angles", 1);
    ros::Publisher pose_pub = n.advertise<nav_msgs::Odometry>("gps/odom", 1);

    int msg_count = 0;
    double val_loading_bucket[3] {0, 0.707, 0.707};
    double val_unloading_bucket[3] {100, 0, 0};

    while(ros::ok()){
        excavator_dongle::actual_angle_1300 angle_msg;
        nav_msgs::Odometry pose_msg;

        if (msg_count % 2 == 0){
            angle_msg.actual_angle4_y = val_unloading_bucket[0];
            pose_msg.pose.pose.orientation.w = val_unloading_bucket[1];
            pose_msg.pose.pose.orientation.z = val_unloading_bucket[2];
        }
        else {
            angle_msg.actual_angle4_y = val_loading_bucket[0];
            pose_msg.pose.pose.orientation.w = val_loading_bucket[1];
            pose_msg.pose.pose.orientation.z = val_loading_bucket[2];
        }

        ++msg_count;
        pose_pub.publish(pose_msg);
        angle_pub.publish(angle_msg);

        ROS_INFO("MSG_COUNT: %d", msg_count);

        loop_rate.sleep();
    }

    return 0;

}