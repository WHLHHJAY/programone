#include <iostream>

#include "ros/ros.h"
#include "nav_msgs/Odometry.h"

#include "kinematics.hpp"
#include "excavator_dongle/actual_angle_1300.h"

struct JointsData {
  double vals[4];

  JointsData &operator=(const JointsData &rhs) {
    for (int i = 0; i < 4; i++) {
      this->vals[i] = rhs.vals[i];
    }
    return *this;
  }
};

struct PoseData {
  // x, y, z
  double pose[3];
  // w, x, y, z
  double quaternion[4];
  // roll, pitch, yaw
  double euler[3];

  PoseData &operator=(const PoseData &rhs) {
    for (int i = 0; i < 3; i++) {
      this->pose[i] = rhs.pose[i];
      this->quaternion[i] = rhs.quaternion[i];
      this->euler[i] = rhs.euler[i];
    }
    this->quaternion[3] = rhs.quaternion[3];

    return *this;
  }
};

void ToEulerAngles(PoseData &pose) {
  // copied from wikipedia
  // roll (x-axis rotation)
  double sinr_cosp = 2.0 * (pose.quaternion[0] * pose.quaternion[1] + pose.quaternion[2] * pose.quaternion[3]);
  double cosr_cosp = 1.0 - 2.0 * (pose.quaternion[1] * pose.quaternion[1] + pose.quaternion[2] * pose.quaternion[2]);
  pose.euler[0] = atan2(sinr_cosp, cosr_cosp);

  // pitch (y-axis rotation)
  double sinp = 2.0 * (pose.quaternion[0] * pose.quaternion[2] - pose.quaternion[3] * pose.quaternion[1]);
  if (fabs(sinp) >= 1) {
    pose.euler[1] = copysign(M_PI / 2, sinp);
  } else {
    pose.euler[1] = asin(sinp);
  }

  // yaw (z-axis rotation)
  double siny_cosp = 2.0 * (pose.quaternion[0] * pose.quaternion[3] + pose.quaternion[1] * pose.quaternion[2]);
  double cosy_cosp = 1.0 - 2.0 * (pose.quaternion[2] * pose.quaternion[2] + pose.quaternion[3] * pose.quaternion[3]);
  pose.euler[2] = atan2(siny_cosp, cosy_cosp);
}

double sensor_val_x[4] = {0, 0, 0, 0};
double sensor_val_y[4] = {0, 0, 0, 0};

void SensorCallback(const excavator_dongle::actual_angle_1300::ConstPtr &msg) {
  sensor_val_x[0] = msg->actual_angle1_x;
  sensor_val_x[1] = msg->actual_angle2_x;
  sensor_val_x[2] = msg->actual_angle3_x;
  sensor_val_x[3] = msg->actual_angle4_x;
  sensor_val_y[0] = msg->actual_angle1_y;
  sensor_val_y[1] = msg->actual_angle2_y;
  sensor_val_y[2] = msg->actual_angle3_y;
  sensor_val_y[3] = msg->actual_angle4_y;
}

PoseData localization_val;

void LocalizationCallback(const nav_msgs::Odometry::ConstPtr &msg) {
  localization_val.pose[0] = msg->pose.pose.position.x;
  localization_val.pose[1] = msg->pose.pose.position.y;
  localization_val.pose[2] = msg->pose.pose.position.z;
  localization_val.quaternion[0] = msg->pose.pose.orientation.w;
  localization_val.quaternion[1] = msg->pose.pose.orientation.x;
  localization_val.quaternion[2] = msg->pose.pose.orientation.y;
  localization_val.quaternion[3] = msg->pose.pose.orientation.z;
}

int main(int argc, char **argv) {
  if (argc < 2) {
    std::cout << "print_data param, param is the desired ros frequency" << std::endl;
    return -1;
  }

  ros::init(argc, argv, "print_data");
  ros::NodeHandle n;

  ros::Rate loop_rate(atoi(argv[1]));

  ros::Subscriber sensor_sub = n.subscribe("/actual_angles", 1, SensorCallback);
  ros::Subscriber localization_sub = n.subscribe("/gps/bucket/odom", 1, LocalizationCallback);

  while (ros::ok()) {
    ros::spinOnce();

    PoseData bucket_pose = localization_val;
    JointsData angles_x, angles_y;
    for (int i = 0; i < 4; ++i) {
      angles_x.vals[i] = sensor_val_x[i];
      angles_y.vals[i] = sensor_val_y[i];
    }

    ToEulerAngles(bucket_pose);

    ROS_INFO("Euler angles of the vehicle [degree]:");
    ROS_INFO("Roll: %f, Pitch: %f, Yaw: %f", 180 / M_PI * bucket_pose.euler[0], 180 * M_PI / bucket_pose.euler[1],
             180 * M_PI / bucket_pose.euler[2]);
    ROS_INFO("Sensor Info [deg]:");
    ROS_INFO("X: %f, %f, %f, %f", angles_x.vals[0], angles_x.vals[1], angles_x.vals[2], angles_x.vals[3]);
    ROS_INFO("Y: %f, %f, %f, %f", angles_y.vals[0], angles_y.vals[1], angles_y.vals[2], angles_y.vals[3]);
    ROS_INFO("----------------------------------------");

    loop_rate.sleep();
  }

  return 0;
}
