#include <stdlib.h>
#include <csignal>

#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "acmsg/ac_arm_status.h"
#include "acmsg/ac_js_status.h"
#include "acmsg/armpose_detailed.h"
#include "acmsg/error_assemble.h"
#include "kinematics.hpp"
#include "counter.hpp"
#include "excavator_dongle/angles_test.h"
#include "excavator_dongle/swing_test.h"
#include "excavator_dongle/actual_angle.h"
#include "backhoe_dongle.hpp"
#include "can_communication.hpp"
#include "excavator_dongle/actual_angle_1300.h"
#include "excavator_dongle/server_info.h"
#include "excavator_dongle/bucket_info.h"

// #define RECORD

// is_offline == true, won't initialize CAN port
bool is_offline = true;
accontrol_can_commu::CanInterface gCanInterface(is_offline);

std::atomic<bool> main_shutdown_flag(false);
std::atomic<bool> can_shutdown_flag(false);

std::mutex upstream_mutex;
std::mutex downstream_mutex;

JointsData raw_joints_ref;
int ctrl_mode_array[4] = {0};
int ref_type[4] = {1};
int ebarrier_mode_array[4] = {1};
bool ebarrier_received = false;
bool ref_data_ready = false;

PoseData raw_center_pose;
PoseData raw_tip_pose;
JointsData raw_angles;

bool gStartCounter = false;
bool gLoadingPointSet = false;

void CounterCallback(const excavator_dongle::server_info::ConstPtr &msg) {
  // listening to the server, enable or disable the counter
  gStartCounter = msg->bucket_count_effect;
  gLoadingPointSet = msg->load_point_sucess;
}

void CenterCallback(const nav_msgs::Odometry::ConstPtr &msg) {
  raw_center_pose.pose[0] = msg->pose.pose.position.x;
  raw_center_pose.pose[1] = msg->pose.pose.position.y;
  raw_center_pose.pose[2] = msg->pose.pose.position.z;

  raw_center_pose.quaternion[0] = msg->pose.pose.orientation.w;
  raw_center_pose.quaternion[1] = msg->pose.pose.orientation.x;
  raw_center_pose.quaternion[2] = msg->pose.pose.orientation.y;
  raw_center_pose.quaternion[3] = msg->pose.pose.orientation.z;
}

void TipCallback(const nav_msgs::Odometry::ConstPtr &msg) {
  raw_tip_pose.pose[0] = msg->pose.pose.position.x;
  raw_tip_pose.pose[1] = msg->pose.pose.position.y;
  raw_tip_pose.pose[2] = msg->pose.pose.position.z;

  raw_tip_pose.quaternion[0] = msg->pose.pose.orientation.w;
  raw_tip_pose.quaternion[1] = msg->pose.pose.orientation.x;
  raw_tip_pose.quaternion[2] = msg->pose.pose.orientation.y;
  raw_tip_pose.quaternion[3] = msg->pose.pose.orientation.z;
}

void JointsCallback1300(const excavator_dongle::actual_angle_1300::ConstPtr &msg) {
  // joints rotates around sensors' y-axis FOR 1300
  raw_angles.vals[0] = msg->actual_angle1_y;
  raw_angles.vals[1] = msg->actual_angle2_y;
  raw_angles.vals[2] = msg->actual_angle3_y;
  raw_angles.vals[3] = msg->actual_angle4_y;
}

void JointsCallback950(const excavator_dongle::actual_angle::ConstPtr &msg) {
  // FOR 950
  raw_angles.vals[0] = 0;
  raw_angles.vals[1] = msg->actual_angle1;
  raw_angles.vals[2] = msg->actual_angle2;
  raw_angles.vals[3] = msg->actual_angle3;

}

void SwingCallback(const excavator_dongle::swing_test::ConstPtr &msg) {
  // This function is the callback of joint angle messages.
  // I don't have that message header now. TO BE MODIFIED!
  raw_angles.vals[0] = 0;//msg->swing_angle; // swing
}

void FSM_SigintHandler(int interrupt_signal) {
  main_shutdown_flag = true;
}

bool verbose_mode = false;
bool record_mode = false;

int main(int argc, char **argv) {
  JointsData angle_sensor_fb; // joint angle sensor data
  JointsData angle_with_pitch;
  // JointsData angle_from_cylinder; // joint angles converted from cylinder extension
  // int cylinder_len[4]; // cylinder extensions
  // JointsData handle_fb; // handle movement
  PoseData center_pose;
  // PoseData tip_pose;



  // parameter check
  if (argc < 4) {
    std::cout << "Usage: rosrun excavator_dongle dongle param1 [optional -v]" << std::endl;
    std::cout << "param1: the ros spin frequency" << std::endl;
    std::cout << "if the option -v is set, this program will print some data to the terminal" << std::endl;
    return 0;
  }

  std::string param2, param3;
  param2 = argv[2];
  
  param3 = argv[3];

  if (param2.compare("-v") == 0) {
    verbose_mode = true;
  }
  if (param3.compare("-r") == 0) {
    record_mode = true;
  }


  // ros init
  ros::init(argc, argv, "backhoe_info_dongle", ros::init_options::NoSigintHandler);
  ros::NodeHandle fsm_handle;
  ros::Publisher angle_planner_pub = fsm_handle.advertise<acmsg::ac_arm_status>("ac_arm_status", 1);
  ros::Publisher tip_pub = fsm_handle.advertise<acmsg::armpose_detailed>("/ac_armpose", 1);
  ros::Publisher counter_pub = fsm_handle.advertise<excavator_dongle::bucket_info>("bucket_info_topic", 1);
  ros::Publisher error_list = fsm_handle.advertise<acmsg::error_assemble>("error_assemble_topic", 1);//error_assemble

  int ros_freq = atoi(argv[1]);
  if (ros_freq <= 0) {
    ros_freq = 1;
  }

  // sigint handler dd
  signal(SIGINT, FSM_SigintHandler);
  {
    if (argc != 5) {
      static std::stringstream _ss_t;
      _ss_t.str("");
      _ss_t << "need input packate path";

      ROS_ERROR_STREAM(" [FILE]: " << " [FUN ]: " << __FUNCTION__
                               << " [LINE]: " << __LINE__
                               << std::endl
                               << setiosflags(std::ios::fixed)
                               << std::setprecision(3)
                               << _ss_t.str() << std::endl);

      return -1;
    }
  }

  

  accontrol_kinematics::kinematics ksolver(argv[4]);
  
  
  excavator_dongle_counter::Counter loading_counter(0, 20);
  ksolver.ParamInit();

  // initialize feedback receiving thread
  /*
  int m_run0=1;
pthread_t can_thread_id;
  if (atoi(argv[1]) == -1){
      ros_freq = 100;
    pthread_create(&can_thread_id, NULL, accontrol_can_commu::ReceiveVehicleCan, &m_run0);
  }
  else{
      // subscribe to a fake CAN node. Used for offline test.
      // it makes little sence to run this in another thread. just for consistency
      ros_freq = atoi(argv[1]); // let's not go too fast. I hate tons of info on screens
      pthread_create(&can_thread_id, NULL, ReadFakeCan, &ros_freq);
      for (int flagi = 0; flagi < 4; flagi++){
          ctrl_mode_array[flagi] = 1;
          ref_type[flagi] = 1;
      }
  } */

  ros::Rate loop_rate(ros_freq);

  ros::Subscriber center_listener = fsm_handle.subscribe("/gps/bucket/odom", 2, CenterCallback);
  ros::Subscriber angle_listener;
  if (ksolver.ID_ID == 1300) {
    angle_listener = fsm_handle.subscribe("/actual_angles", 2, JointsCallback1300);
  } else if (ksolver.ID_ID == 950) {
    angle_listener = fsm_handle.subscribe("/actual_angles", 2, JointsCallback950);
  } else {
    std::cerr << "backhoe_type is not specified! Check the end of kinematics.hpp!" << std::endl;
    return -1;
  }
  // ros::Subscriber angle_listener = fsm_handle.subscribe("/actual_angles", 2, JointsCallback);

  // rostopic /swing_angle is a fake data source, used for tests
  ros::Subscriber swing_listener = fsm_handle.subscribe("/swing_angle", 2, SwingCallback);

  // This subscriber is intended to work with the GUI, I don't have the topic and message type yet
  // TO BE MODIFIED!
  ros::Subscriber counter_listener = fsm_handle.subscribe("/server_info_topic", 1, CounterCallback);

  FILE *fp = NULL;
  char file_name_[100];
  std::string file_name;
  bool RECORE_flag = 0;
  if (record_mode) {
    RECORE_flag = 1;
    file_name = GetTime();
    file_name = "./" + file_name + ".txt";
    strcpy(file_name_, file_name.c_str());

    fp = fopen(file_name_, "a");
    fprintf(fp, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\n", "time", "raw_boom", "raw_stick", "raw_bucket",
            "angle_boom", "angle_stick", "angle_bucket", "roll", "pitch", "yaw", "x", "y", "z",
            "x2center", "y2center", "z2center");
    fclose(fp);
  }
  // kinematic solver
  // accontrol_kinematics::kinematics ksolver;
  // excavator_dongle_counter::Counter loading_counter(0, 20);
  double loading_heading = 0;

  // hack
  int counter_hacker = 0;

  while (ros::ok() && !main_shutdown_flag.load()) {

    // pop all callbacks in the global queue
    ros::spinOnce();

    acmsg::error_assemble err_msg;
    if ((fabs(raw_angles.vals[1]) <= 0.000001) && (fabs(raw_angles.vals[2]) <= 0.000001) &&
        (fabs(raw_angles.vals[3]) <= 0.000001)) {
      err_msg.ID = 1;
    } else {
      err_msg.ID = 0;
    }
    error_list.publish(err_msg);

    // read localization data, I don't know the communication quality, just assume it works fine
    angle_sensor_fb = raw_angles;
    center_pose = raw_center_pose;
    // all angles converts to the form that are ready for forward kinematics calculation
    // This function should be modified based on the installation of angle sensors.
    ksolver.RawAngleConversion(angle_sensor_fb.vals[0], angle_sensor_fb.vals[1],
                               angle_sensor_fb.vals[2], angle_sensor_fb.vals[3]);
    // the cabin's heading in the East-North-Sky frame
    double heading = HeadingAngleEstimation(center_pose);
    double roll = center_pose.euler[0];
    double pitch = center_pose.euler[1];

    // hack
    // angle_with_pitch = raw_angles;
    // ksolver.RawAngleConversion(angle_with_pitch.vals[0], angle_with_pitch.vals[1],
    // angle_with_pitch.vals[2], angle_with_pitch.vals[3]);
    // angle_with_pitch.vals[1] -= 6;//pitch;
    // angle_with_pitch.vals[2] -= 6;//pitch;
    // angle_with_pitch.vals[3] -= 6;//pitch;
    // ksolver.setPosC(0, angle_with_pitch.vals[1], angle_with_pitch.vals[2], angle_with_pitch.vals[3]);
    // double temp_vals[4] = {0, 0, 0, 0};
    // ksolver.SetCenterEnsFrame(temp_vals, 4);
    // ksolver.GetEnsPose();
    // ROS_INFO("Bucket Tip Pitch removed (x, y, z): %f, %f, %f", ksolver.pos_ens_frame[0],
    // ksolver.pos_ens_frame[1], ksolver.pos_ens_frame[2]);
    // ROS_INFO("Joint Angles Pitch removed: %f, %f, %f, %f", angle_with_pitch.vals[0], angle_with_pitch.vals[1],
    // angle_with_pitch.vals[2], angle_with_pitch.vals[3]);
    // solving forward kinematics
    ksolver.setPosC(angle_sensor_fb.vals[0], angle_sensor_fb.vals[1],
                    angle_sensor_fb.vals[2], angle_sensor_fb.vals[3]);
    double angles_to_send[4] = {0, 0, 0, 0};
    ksolver.GetAngleToSend(angles_to_send[0], angles_to_send[1], angles_to_send[2], angles_to_send[3]);
    // double center_pose_vals[4] = {heading, center_pose.pose[0], center_pose.pose[1], center_pose.pose[2]};
    double center_pose_vals[4] = {0, 0, 0, 0}; // heading is not computed in this program anymore
    ksolver.SetCenterEnsFrame(center_pose_vals, 4);
    ksolver.GetEnsPose();

    /********** Loading Counter **********/
    // if the loading point is set, reset the counter's truck position
    if (gLoadingPointSet) {
      // note that the ResetCounter will clear all data in the counter
      // So make sure the gLoadingPointSet is set to false after usage.
      loading_heading = heading * 180 / M_PI;
      loading_counter.ResetCounter(loading_heading);
      gLoadingPointSet = false;
    }

    int count = 0;
    if (gStartCounter) {
      loading_counter.CountAttempt(heading * 180 / M_PI, angle_sensor_fb.vals[3]);
      count = loading_counter.GetLoadingCount();
      // print states for debug
      std::cout << "\n\n" << std::endl;
      loading_counter.PrintStates();
      std::cout << "\n\n" << std::endl;
    } else {
      loading_counter.ResetCounter(loading_heading);
    }

    // //hack
    // ++counter_hacker;

    // publish the results to \bucket_info_topic
    excavator_dongle::bucket_info count_msg;

    // // hack
    // count  = counter_hacker;

    count_msg.current_bucket_count = count;
    counter_pub.publish(count_msg);
    // End loading counter

    // Assembling the feedback message and sending it to the planner.
    acmsg::ac_arm_status fb_msg;
    acmsg::armpose_detailed tip_msg;

    for (int i = 0; i < 4; i++) {
      fb_msg.deg[i] = angle_sensor_fb.vals[i];
    }
    fb_msg.deg_buk_pitch = angle_sensor_fb.vals[3];

    // position in cm
    for (int msgi = 0; msgi < 3; msgi++) {
      fb_msg.bom[msgi] = ksolver.posW[0][msgi] / 10;
      fb_msg.stk[msgi] = ksolver.posW[1][msgi] / 10;
      fb_msg.buk[msgi] = ksolver.posW[2][msgi] / 10;
      fb_msg.tip[msgi] = ksolver.posW[3][msgi] / 10;
      fb_msg.bom_up[msgi] = ksolver.posInter[0][msgi] / 10;
      fb_msg.stk_up[msgi] = ksolver.posInter[1][msgi] / 10;
      fb_msg.buk_up[msgi] = ksolver.posInter[2][msgi] / 10;
      fb_msg.tip_up[msgi] = ksolver.posInter[3][msgi] / 10;

      tip_msg.position0[msgi] = ksolver.posW[0][msgi] / 10;
      tip_msg.position1[msgi] = ksolver.posW[1][msgi] / 10;
      tip_msg.position2[msgi] = ksolver.posW[2][msgi] / 10;
      tip_msg.position3[msgi] = ksolver.posW[3][msgi] / 10;
      tip_msg.positionup0[msgi] = ksolver.posInter[0][msgi] / 10;
      tip_msg.positionup1[msgi] = ksolver.posInter[1][msgi] / 10;
      tip_msg.positionup2[msgi] = ksolver.posInter[2][msgi] / 10;
      tip_msg.positionup3[msgi] = ksolver.posInter[3][msgi] / 10;
    }

    // overwrite tip position in vehicle frame with position in ENS frame
    fb_msg.tip[0] = ksolver.pos_ens_frame[0] / 10;
    fb_msg.tip[1] = ksolver.pos_ens_frame[1] / 10;
    fb_msg.tip[2] = ksolver.pos_ens_frame[2] / 10;

    tip_msg.position3[0] = ksolver.pos_ens_frame[0] / 10;
    tip_msg.position3[1] = ksolver.pos_ens_frame[1] / 10;
    tip_msg.position3[2] = ksolver.pos_ens_frame[2] / 10;
    tip_msg.agl[0] = angles_to_send[0];
    tip_msg.agl[1] = angles_to_send[1];
    tip_msg.agl[2] = angles_to_send[2];
    tip_msg.agl[3] = angles_to_send[3];

    fb_msg.header.stamp = ros::Time::now();
    angle_planner_pub.publish(fb_msg);
    tip_msg.header.stamp = ros::Time::now();
    tip_pub.publish(tip_msg);

    if (verbose_mode) {
      ROS_INFO("Joint Angles: %f, %f, %f, %f", angle_sensor_fb.vals[0], angle_sensor_fb.vals[1],
               angle_sensor_fb.vals[2], angle_sensor_fb.vals[3]);
      ROS_INFO("Rotation Center Position (x, y, z, heading): %f, %f, %f, %f", center_pose.pose[0],
               center_pose.pose[1], center_pose.pose[2], heading * 180 / M_PI);
      ROS_INFO("Bucket Tip Position (vehicle frame): %f, %f ,%f", ksolver.posInter[3][0], ksolver.posInter[3][1],
               ksolver.posInter[3][2]);
      ROS_INFO("Bucket Tip Position (x, y, z): %f, %f, %f", ksolver.pos_ens_frame[0],
               ksolver.pos_ens_frame[1], ksolver.pos_ens_frame[2]);
      ROS_INFO("Count of Loading: %d", count);
      ROS_INFO("In degrees, Roll: %f, Pitch: %f, Yaw: %f", 180 * roll / M_PI, 180 * pitch / M_PI, 180 * heading / M_PI);
    }

    loop_rate.sleep();

    if (record_mode) {
      fp = fopen(file_name_, "a");

      fprintf(fp, "%s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\n", GetTime().c_str(), raw_angles.vals[1],
              raw_angles.vals[2], raw_angles.vals[3],
              angle_sensor_fb.vals[1], angle_sensor_fb.vals[2], angle_sensor_fb.vals[3], center_pose.euler[0],
              center_pose.euler[1], center_pose.euler[2],
              ksolver.posInter[3][0], ksolver.posInter[3][1], ksolver.posInter[3][2], center_pose.pose[0],
              center_pose.pose[1], center_pose.pose[2]
      );
      fclose(fp);
    }

  } // end main working loop

  // can_shutdown_flag.store(true); // shutdown CAN-listening thread

  ROS_INFO("All sub threads have joined, shuting down ros and CAN communication");
  ros::shutdown();

  return 0;
}
