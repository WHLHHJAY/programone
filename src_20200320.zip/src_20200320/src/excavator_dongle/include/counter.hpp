#ifndef EXCAVATOR_DONGLE_COUNTER
#define EXCAVATOR_DONGLE_COUNTER

#include <iostream>
#include <cmath>

namespace excavator_dongle_counter{
// This counter should be initialized right after the loading point is set.
// There are 2 states inside, namely the loading bucket and the unloading bucket.
// Once initialized, every 2 state transitions will trigger an increment in the loading_count.
class Counter{
    int loading_count = 0;
    int num_state_trans = 0;
    bool bucket_over_truck = true;
    bool bucket_over_mineral = false;
    // target_truck_angle, the upper body angle at which the bucket is over the turck
    double target_truck_angle;
    // +/- some degrees around target_truck_angle 
    double unloading_zone_width; 

    bool StateTransition(const double current_swing_angle, const double current_bucket_angle){
        bool outside_unloading_zone = (std::abs(current_swing_angle - target_truck_angle) > unloading_zone_width);
        bool bucket_holding  = (current_bucket_angle < -135);
        bool bucket_unloading = (current_bucket_angle > -90);

        // bucket is outside the loading zone, holding again and current state is bucket_over_truck
        bool trans_to_bucket_loading = bucket_holding && outside_unloading_zone && bucket_over_truck;
        // bucket is inside the loading zone, unholding and the current state is bucket_over_mineral
        bool trans_to_bucket_unloading = bucket_unloading && (!outside_unloading_zone) && bucket_over_mineral;

        if (trans_to_bucket_loading){
            bucket_over_truck = false;
            bucket_over_mineral = true;
            ++num_state_trans;
        }
        if (trans_to_bucket_unloading){
            bucket_over_truck = true;
            bucket_over_mineral = false;
            ++num_state_trans;
        }

        return trans_to_bucket_unloading || trans_to_bucket_loading;
    }

public:
    // The defalut constructor is deleted on purpose, don't create it again
    Counter() = delete;
    // initialize with truck position and loading zone size
    Counter(const double loading_angle, const double load_zone = 5){
        target_truck_angle = loading_angle;
        unloading_zone_width = load_zone;
        loading_count = 0;
        num_state_trans = 0;
    }

    bool CountAttempt(const double current_swing_angle, const double current_bucket_angle){
        bool state_changed = StateTransition(current_swing_angle, current_bucket_angle);
        if (num_state_trans != 0 && num_state_trans % 2 == 0 && state_changed){
            ++loading_count;
        }
    }

    inline const int GetLoadingCount(){
        return loading_count;
    }

    inline const void PrintStates(){
        std::cout << "Current loading count: " << loading_count << std::endl;
        std::cout << "Current state transition count: " << num_state_trans << std::endl;
        if (bucket_over_mineral){
            std::cout << "Bucket is over the mineral" << std::endl;
        }
        else if (bucket_over_truck){
            std::cout << "Bucket is over the truck" << std::endl;
        }
    }

    inline void ResetCounter(const double truck_angle = 0){
        loading_count = 0;
        num_state_trans = 0;
        bucket_over_truck = true;
        bucket_over_mineral = false;
        target_truck_angle = truck_angle;
    }

};


}

#endif