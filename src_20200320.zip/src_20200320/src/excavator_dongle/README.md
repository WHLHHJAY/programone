ROS package for bucket tip localization

catkin_make install -DCATKIN_WHITELIST_PACKAGES="excavator_dongle"

roslanuch excavator_dongle excavator_dongle.launch
=====

