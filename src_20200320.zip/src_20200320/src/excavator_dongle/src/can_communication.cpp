#include <stdio.h>
#include <atomic>
#include <iostream>
#include <mutex>
#include <sstream>
#include <sys/time.h>

#include "can_communication.hpp"
#include "backhoe_dongle.hpp"
#include "can_matrix.hpp"

extern std::atomic<bool> can_data_ready;
extern std::atomic<bool> can_shutdown_flag;
extern accontrol_can_commu::CanInterface gCanInterface;

namespace accontrol_can_commu {

CanInterface::CanInterface(const bool is_offline) {
  can_data_ready.store(false);
  if (is_offline) {
    is_simulation = true;
    std::cout << "Listening to fake CAN bus" << std::endl;
  } else {
    is_simulation = false;
    OpenDevice();
    InitDevice();
  }
}

void CanInterface::OpenDevice() {
  int dwRel;
  dwRel = EMUCOpenSocketCAN(port);
  if (dwRel == 0) {
    printf("open device success!\n");
  } else if (dwRel == 1) {
    printf("open device failed!\n");
  } else {
    printf("unknown mistake!\n");
  }
}

void CanInterface::CloseDevice() {
  int dwRel;
  dwRel = EMUCCloseDevice(port);
  if (dwRel == 0) {
    printf("close the can success!\n");
  }
}

void CanInterface::ReadDeviceInf() {
  VER_INFO ver;

  EMUCShowVer(port, &ver);
  printf("the API version is %s \n", ver.api);
  printf("the Firmware version is %s \n", ver.fw);
  printf("the model is %s \n", ver.model);
}

void CanInterface::ResetDevice() {
  int dwRel;
  dwRel = EMUCResetCAN(port);
  if (dwRel != 0) {
    printf("reset device failed!\n");
  } else {
    printf("reset device successed!\n");
  }
}

void CanInterface::SetFilter() {
  FILTER_INFO filter_cfg;
  filter_cfg.CAN_port = FIFTER_CAN_1;
  filter_cfg.flt_type = FIFTER_TYPE;
  filter_cfg.flt_id = FIFTER_ID;
  filter_cfg.mask = FIFTER_MASK;

  EMUCSetFilter(port, &filter_cfg);
}

void CanInterface::InitDevice() {
  int dwRel;
  dwRel = EMUCInitCAN(port, EMUC_INACTIVE, EMUC_INACTIVE);
  ReadDeviceInf();
  ResetDevice();
  EMUCClearFilter(port, 0);
  EMUCClearFilter(port, 1);
  EMUCSetBaudRate(port, EMUC_BAUDRATE_250K, EMUC_BAUDRATE_250K);
  EMUCSetErrorType(port, EMUC_DIS_ALL);
  EMUCSetMode(port, CAN1_mode, CAN2_mode);
  EMUCEnableSendQueue(port, true, 200);
  SetFilter();
  EMUCInitCAN(port, EMUC_ACTIVE, EMUC_ACTIVE);
}

void CanInterface::TransToBits(const double *pwm_vals, const int len_pwms) {
  // Transfer control commnad to unsigned char
  // From int to unsigned char, lowest byte is taken
  double pwm_time_10[4];
  for (int i = 0; i < 4; i++) {
    // x10 to preserve 1 decimal digit
    pwm_time_10[i] = pwm_vals[i] * 10;
  }

  for (int i = 0; i < 4; i++) {
    if (pwm_vals[i] >= 0) {
      pwm_in_bits.high[i] = (((int) pwm_time_10[i]) >> 8) & 0xFF;
      pwm_in_bits.low[i] = (((int) pwm_time_10[i])) & 0xFF;
    } else {
      pwm_in_bits.high[i] = (((int) abs(pwm_time_10[i])) >> 8) & 0xFF;
      pwm_in_bits.low[i] = (((int) abs(pwm_time_10[i]))) & 0xFF;
      pwm_in_bits.high[i] |= 0x80; // The first bit is used as sign
    }
  }
  // always enable control
  pwm_in_bits.high[0] |= 0x40;
} // end TransToBits

void CanInterface::SendCanPackage() {
  int dewel = -1;
  int Reset_flag = 0;

  can_data_pack.CAN_port = EMUC_CAN_1;
  can_data_pack.id_type = EMUC_EID;
  can_data_pack.rtr = EMUC_DIS_RTR;
  can_data_pack.dlc = 8;
  can_data_pack.msg_type = EMUC_DATA_TYPE;
  can_data_pack.id = EXCAVATOR_ARM_CTR;

  int j = 0;
  for (int i = 0; i < 8; i = i + 2) {
    can_data_pack.data[i] = pwm_in_bits.high[j];
    can_data_pack.data[i + 1] = pwm_in_bits.low[j];
    j++;
  }
  if (!is_simulation) {
    // only call EMUCSend when the EMUC is enabled.
    dewel = EMUCSend(port, &can_data_pack);
  }

}

void CanInterface::PrintCanDataPack() {
  // Used for validation
  /*
  std::cout << "raw bits in can_data_pack: " << std::endl;
  for (int i = 0; i < 8; i++){
      std::cout << (int)can_data_pack.data[i] << std::endl;
  } */

  double trans_pwms[4] = {0};
  int zeroInt = 0;
  std::cout << "Following data are sent to CAN: " << std::endl;
  if ((int) (((int) can_data_pack.data[0]) & 0x40) != zeroInt) {
    std::cout << "  jointControlFlag == 1" << std::endl;
  } else {
    std::cout << "  jointControlFlag == 0" << std::endl;
  }

  // explicit type conversion is of vital importance
  int j = 0;
  for (int i = 0; i < 4; i++) {
    if ((int) ((int) (can_data_pack.data[j]) & 0x80) == zeroInt) {
      // positive
      trans_pwms[i] = (((int) (can_data_pack.data[j] & 0xBF)) << 8) + (int) can_data_pack.data[j + 1];
    } else {
      trans_pwms[i] = -((((int) (((can_data_pack.data[j] & 0XBF) & 0x7F))) << 8) + (int) can_data_pack.data[j + 1]);
    }
    j += 2;
    trans_pwms[i] /= 10;
  }

  std::cout << " Control commands: " << std::endl;
  std::cout << "  swing: " << trans_pwms[0] << std::endl;
  std::cout << "  boom   " << trans_pwms[1] << std::endl;
  std::cout << "  stick  " << trans_pwms[2] << std::endl;
  std::cout << "  bucket " << trans_pwms[3] << std::endl;
}

void *ReceiveVehicleCan(void *param) {
  enum JointsName { swing, boom, stick, bucket };
  NON_BLOCK_INFO CAN_recv;
  DATA_INFO data_recv[2500];

  int dwRel = 0;
  CAN_recv.cnt = 2500;
  CAN_recv.interval = 0;
  CAN_recv.can_frame_info = data_recv;

  while (!can_shutdown_flag.load()) {
    dwRel = EMUCReceive(port, data_recv);
    // dwRel is the number of data sent by PLC
    if (dwRel > 0) {
      for (int i = 0; i < dwRel; i++) {
        std::lock_guard<std::mutex> guard(upstream_mutex);
        // Following processes should be modified for new excavator
        if (CAN_recv.can_frame_info[i].id == 0x18FF1A00) {
          gCanInterface.angles_fb[boom] = (double(CAN_recv.can_frame_info[i].data[0])) / 3 - 30;
          gCanInterface.pwms_command_fb[boom] =
                  ((int(CAN_recv.can_frame_info[i].data[1]) << 8) + CAN_recv.can_frame_info[i].data[2]) & 0xFFFF;
          gCanInterface.current_res_fb[boom] =
                  ((int(CAN_recv.can_frame_info[i].data[3]) << 8) + CAN_recv.can_frame_info[i].data[4]) & 0xFFFF;
          gCanInterface.current_res_fb[boom] = gCanInterface.current_res_fb[boom] / 0.001;
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1B00) {
          gCanInterface.angles_fb[stick] =
                  ((int(CAN_recv.can_frame_info[i].data[0]) << 8) + CAN_recv.can_frame_info[i].data[1]) & 0xFFFF;
          gCanInterface.angles_fb[stick] = gCanInterface.angles_fb[2] / 300;
          gCanInterface.pwms_command_fb[stick] =
                  ((int(CAN_recv.can_frame_info[i].data[2]) << 8) + CAN_recv.can_frame_info[i].data[3]) & 0xFFFF;
          gCanInterface.current_res_fb[stick] =
                  ((int(CAN_recv.can_frame_info[i].data[4]) << 8) + CAN_recv.can_frame_info[i].data[5]) & 0xFFFF;
          gCanInterface.current_res_fb[stick] = gCanInterface.current_res_fb[stick] / 0.001;
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1D00) {
          gCanInterface.angles_fb[bucket] =
                  ((int(CAN_recv.can_frame_info[i].data[0]) << 8) + CAN_recv.can_frame_info[i].data[1]) & 0xFFFF;
          gCanInterface.angles_fb[bucket] = gCanInterface.angles_fb[bucket] / 300;
          gCanInterface.pwms_command_fb[bucket] =
                  ((int(CAN_recv.can_frame_info[i].data[2]) << 8) + CAN_recv.can_frame_info[i].data[3]) & 0xFFFF;
          gCanInterface.current_res_fb[bucket] =
                  ((int(CAN_recv.can_frame_info[i].data[4]) << 8) + CAN_recv.can_frame_info[i].data[5]) & 0xFFFF;
          gCanInterface.current_res_fb[bucket] = gCanInterface.current_res_fb[bucket] / 0.001;
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1E00) {
          gCanInterface.angles_fb[swing] =
                  ((int(CAN_recv.can_frame_info[i].data[0]) << 8) + CAN_recv.can_frame_info[i].data[1]) & 0xFFFF;
          gCanInterface.angles_fb[swing] = gCanInterface.angles_fb[swing] / 180;
          gCanInterface.pwms_command_fb[swing] =
                  ((int(CAN_recv.can_frame_info[i].data[2]) << 8) + CAN_recv.can_frame_info[i].data[3]) & 0xFFFF;
          gCanInterface.current_res_fb[swing] =
                  ((int(CAN_recv.can_frame_info[i].data[4]) << 8) + CAN_recv.can_frame_info[i].data[5]) & 0xFFFF;
          gCanInterface.current_res_fb[swing] = gCanInterface.current_res_fb[swing] / 0.001;
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1F00) {
          // cylinder lengths [mm]
          gCanInterface.len1_boom =
                  ((int) (CAN_recv.can_frame_info[i].data[0]) << 8) + ((int) CAN_recv.can_frame_info[i].data[1]) &
                  0xFFFF;
          gCanInterface.len2_boom =
                  ((int) (CAN_recv.can_frame_info[i].data[2]) << 8) + ((int) CAN_recv.can_frame_info[i].data[3]) &
                  0xFFFF;
          gCanInterface.len_stick =
                  ((int) (CAN_recv.can_frame_info[i].data[4]) << 8) + ((int) CAN_recv.can_frame_info[i].data[5]) &
                  0xFFFF;
          gCanInterface.len_bucket =
                  ((int) (CAN_recv.can_frame_info[i].data[6]) << 8) + ((int) CAN_recv.can_frame_info[i].data[7]) &
                  0xFFFF;
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1600) {
          gCanInterface.boom_joy = (int) CAN_recv.can_frame_info[i].data[0];
          gCanInterface.bucket_joy = (int) CAN_recv.can_frame_info[i].data[1];
          gCanInterface.right_sign = (int) CAN_recv.can_frame_info[i].data[6];
        } else if (CAN_recv.can_frame_info[i].id == 0x18FF1700) {
          gCanInterface.stick_joy = (int) CAN_recv.can_frame_info[i].data[0];
          gCanInterface.swing_joy = (int) CAN_recv.can_frame_info[i].data[1];
          gCanInterface.left_sign = (int) CAN_recv.can_frame_info[i].data[7];
        }
      } // end for

      gCanInterface.can_data_ready.store(true);

    } else if (dwRel == -1) {
      printf("receive can wrong\n");
    }

    return 0;
  } // end while

  pthread_exit(0);
} // end ReceiveVehicleCan


} // end namespace accontrol_can_commu