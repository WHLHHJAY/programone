#ifndef ACCONTROL_CAN_COMMUNICATION
#define ACCONTROL_CAN_COMMUNICATION

// If this class is to be compiled seperately, following steps are needed:
// 1. make sure you have told g++ where the libemuc.a and lib_emuc.h are
// 2. define the external variables, i.e., 
//      std::atomic<bool> main_shutdown_flag(false);
//      std::atomic<bool> can_shutdown_flag(false);
//      std::mutex upstream_mutex;
// 3. link to -lpthread, which is required by libemuc.a

#include <string>
#include <atomic>

extern "C" {
#include "lib_emuc.h"
} 
// libemuc.a is a C library.

namespace accontrol_can_commu{

class CanInterface{
// a struct might be better? all members are public
// let it be...
public:
    bool is_simulation;
    std::atomic<bool> can_data_ready;
    enum JointsName {swing, boom, stick, bucket};
    double angles_fb[4];
    double pwms_command_fb[4];
    double current_res_fb[4]; // current

    int len1_boom;
    int len2_boom;
    int len_stick;
    int len_bucket;

    int swing_joy;
    int boom_joy;
    int stick_joy;
    int bucket_joy;
    int left_sign;
    int right_sign;

    DATA_INFO can_data_pack;

    struct {
        unsigned char high[4];
        unsigned char low[4];
    } pwm_in_bits;

    void OpenDevice();
    void CloseDevice(); 
	void ReadDeviceInf();
	void ResetDevice();
	void SetFilter();
    void InitDevice();

    void TransToBits(const double* pwm_vals, const int len_pwms);
    void SendCanPackage();
    // static void* ReceiveVehicleCan(void* param);

    CanInterface(const bool is_offline);

    void PrintCanDataPack();
}; // end CanInterface

void* ReceiveVehicleCan(void* param);

} // accontrol_can_commu

#endif