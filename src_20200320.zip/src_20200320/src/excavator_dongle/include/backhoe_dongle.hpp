#ifndef ACCONTROL_DONGLE_FSM
#define ACCONTROL_DONGLE_FSM

#include <atomic>
#include <mutex>

#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "acmsg/ac_control.h"
#include "can_communication.hpp"
// Global State Transition FLags, initialized in backhoe_control_fsm.cpp
extern std::atomic<bool> main_shutdown_flag;
extern std::atomic<bool> ebarrier_enable_flag;
extern int ebarrier_enable_mode[4];

// Mutex locks, initialized in backhoe_control_fsm.cpp
extern std::mutex upstream_mutex;
extern std::mutex downstream_mutex;

struct JointsData{
    double vals[4];
    JointsData& operator=(const JointsData& rhs){
        for (int i = 0; i < 4; i++){
            this->vals[i] = rhs.vals[i];
        }
        return *this;
    }
};

struct PoseData{
    // x, y, z
    double pose[3];
    // w, x, y, z
    double quaternion[4];
    // roll, pitch, yaw
    double euler[3];
    PoseData& operator=(const PoseData& rhs){
        for (int i = 0; i < 3; i++){
            this->pose[i] = rhs.pose[i];
            this->quaternion[i] = rhs.quaternion[i];
            this->euler[i] = rhs.euler[i];
        }
        this->quaternion[3] = rhs.quaternion[3];

        return *this;
    }
};

struct CylinderData{
    // len1boom, len2boom, len_stick, len_bucket
    double vals[4];
    int left_handle_sign;
    int right_handle_sign;

}; 

// defined in fsm_functions.cpp
void RefCallback(const acmsg::ac_control::ConstPtr& msg);

void EbarrierModeCallback(const acmsg::ac_control::ConstPtr& msg);

double SwingAngleEstimation(PoseData& center, const PoseData& tip);

double HeadingAngleEstimation(PoseData& center);

void ToEulerAngles(PoseData& pose);

void TipCallabck(const nav_msgs::Odometry::ConstPtr& msg);

void CenterCallback(const nav_msgs::Odometry::ConstPtr& msg);

void RefCallback(const acmsg::ac_control::ConstPtr& msg);

void* ReadFakeCan(void* param);

std::string GetTime();

#endif