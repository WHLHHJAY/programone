# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 10:13:08 2019

@author: xyfu
"""

import numpy as np
import rosbag
import sys

if len(sys.argv) != 3:
    print("Usage: python localization_stat.py bagname1 bagname2")
    sys.exit()

bag_init_name = sys.argv[1]
bag_end_name = sys.argv[2] # /ac_armpose

bag_init = rosbag.Bag(bag_init_name, 'r')
bag_end = rosbag.Bag(bag_end_name, 'r')

x_init = []
y_init = []
z_init = []
x_end = []
y_end = []
z_end = []

for topic, msg, t in bag_init.read_messages("/ac_armpose"):
    x_init.append(msg.position3[0])
    y_init.append(msg.position3[1])
    z_init.append(msg.position3[2])

for topic, msg, t in bag_end.read_messages("/ac_armpose"):
    x_end.append(msg.position3[0])
    y_end.append(msg.position3[1])
    z_end.append(msg.position3[2])
    
mean_init = np.array([np.mean(x_init), np.mean(y_init), np.mean(z_init)])
std_init = np.array([np.std(x_init), np.std(y_init), np.std(z_init)])
mean_end = np.array([np.mean(x_end), np.mean(y_end), np.mean(z_end)])
std_end = np.array([np.std(x_end), np.std(y_end), np.std(z_end)])

delta_mean = mean_end - mean_init
delta_norm = np.linalg.norm(delta_mean)
delta_std = np.linalg.norm(np.array([[std_init],[std_end]]), axis=0)

print ("mean_init: (%f, %f, %f)" % (mean_init[0], mean_init[1], mean_init[2]))
print ("std_init: (%f, %f, %f)" % (std_init[0], std_init[1], std_init[2]))
print ("mean_end: (%f, %f, %f)" % (mean_end[0], mean_end[1], mean_end[2]))
print ("std_end: (%f, %f, %f)" % (std_end[0], std_end[1], std_end[2]))

print ("delta_mean: (%f, %f, %f)" % (delta_mean[0], delta_mean[1], delta_mean[2]))
print ("delta_norm: %f, delta_norm_std: %f " % (delta_norm, np.max(delta_std)))
print ("delta_std: (%f, %f, %f)" % (delta_std[0][0], delta_std[0][1], delta_std[0][2]))
