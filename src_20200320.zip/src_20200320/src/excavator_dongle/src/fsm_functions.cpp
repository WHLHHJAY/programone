#include <sys/time.h>
#include <string>
#include <sstream>
#include <atomic>
#include <cmath>

#include "ros/ros.h"
#include "acmsg/ac_control.h"
#include "backhoe_dongle.hpp"
#include "can_communication.hpp"
#include "nav_msgs/Odometry.h"
#include "fakeFeedback/fakeFeedback.h"

extern JointsData raw_joints_ref;
extern accontrol_can_commu::CanInterface gCanInterface;
extern int ctrl_mode_array[4];
extern int ref_type[4];
extern int ebarrier_mode_array[4];
extern bool ref_data_ready;
extern bool ebarrier_received;
extern std::atomic<bool> main_shutdown_flag;

void RefCallback(const acmsg::ac_control::ConstPtr &msg) {
  for (int i = 0; i < 4; i++) {
    raw_joints_ref.vals[i] = msg->deg[i];
    ctrl_mode_array[i] = msg->able[i];
    ref_type[i] = msg->closeloop[i];
  }
  ref_data_ready = true;
}

void EbarrierModeCallback(const acmsg::ac_control::ConstPtr &msg) {
  // don't ask me why there are 2 subscribers. not my fault
  for (int i = 0; i < 4; i++) {
    ebarrier_mode_array[i] = msg->able[i];
  }
  ebarrier_received = true;
}

void FakeCanCallback(const accontrol_can::fakeFeedback::ConstPtr &msg) {
  std::lock_guard<std::mutex> guard(upstream_mutex);
  gCanInterface.angles_fb[0] = msg->fakeAngleSwing;
  gCanInterface.angles_fb[1] = msg->fakeAngleBoom;
  gCanInterface.angles_fb[2] = msg->fakeAngleStick;
  gCanInterface.angles_fb[3] = msg->fakeAngleBucket;
  gCanInterface.len1_boom = msg->fake_cylinder_boom1;
  gCanInterface.len2_boom = msg->fake_cylinder_boom2;
  gCanInterface.len_stick = msg->fake_cylinder_stick;
  gCanInterface.len_bucket = msg->fake_cylinder_bucket;

  gCanInterface.can_data_ready.store(true);
}


void *ReadFakeCan(void *param) {
  int *ros_freq = (int *) param;
  ros::NodeHandle n;
  ros::Subscriber sub_to_fake = n.subscribe("fakeCAN_upward", 1, FakeCanCallback);
  while (ros::ok() && !main_shutdown_flag.load()) {
    ros::spinOnce();
  }
  return 0;
}


double rad2deg(const double &_rad) {
  return _rad * 180 / M_PI;
}

void ToEulerAngles(PoseData &pose) {
  // copied from wikipedia
  // roll (x-axis rotation)
  double sinr_cosp = 2.0 * (pose.quaternion[0] * pose.quaternion[1] + pose.quaternion[2] * pose.quaternion[3]);
  double cosr_cosp = 1.0 - 2.0 * (pose.quaternion[1] * pose.quaternion[1] + pose.quaternion[2] * pose.quaternion[2]);
  pose.euler[0] = atan2(sinr_cosp, cosr_cosp);

  // pitch (y-axis rotation)
  double sinp = 2.0 * (pose.quaternion[0] * pose.quaternion[2] - pose.quaternion[3] * pose.quaternion[1]);
  if (fabs(sinp) >= 1) {
    pose.euler[1] = copysign(M_PI / 2, sinp);
  } else {
    pose.euler[1] = asin(sinp);
  }

  // yaw (z-axis rotation)
  double siny_cosp = 2.0 * (pose.quaternion[0] * pose.quaternion[3] + pose.quaternion[1] * pose.quaternion[2]);
  double cosy_cosp = 1.0 - 2.0 * (pose.quaternion[2] * pose.quaternion[2] + pose.quaternion[3] * pose.quaternion[3]);
  pose.euler[2] = atan2(siny_cosp, cosy_cosp);
}

double SwingAngleEstimation(PoseData &center, const PoseData &tip) {
  // THIS FUNCTION IS MEANINGLESS, DON'T USE IT!
  ToEulerAngles(center);
  // tip.ToEulerAngles();
  double delta_x = tip.pose[0] - center.pose[0];
  double delta_y = tip.pose[1] - center.pose[1];
  if (delta_x == 0 && delta_y == 0) {
    return 0; // this shouldn't happen though...
  } else {
    double delta_theta = atan2(delta_y, delta_x);
    // return rad2deg(center.euler[2] - delta_theta);
    return rad2deg(center.euler[2]);
  }
}


// return the heading angle of the cabin in the global East-North-Sky frame
double HeadingAngleEstimation(PoseData &center) {
  ToEulerAngles(center);
  return center.euler[2];
}

std::string num2str(int i) {
  std::stringstream ss;
  ss << i;
  return ss.str();
}

std::string GetTime() {
  int hour_temp, minute_temp, second_temp, m_second_temp;
  int hour_temp1, hour_temp2;
  std::string hour_s, minute_s, second_s, m_second_s;
  std::string string_time;

  struct timeval tv;
  gettimeofday(&tv, NULL);
  if (tv.tv_sec >= 3600) {
    hour_temp = tv.tv_sec / 3600;
    hour_temp1 = hour_temp / 24;
    hour_temp2 = (hour_temp - hour_temp1 * 24) + 8;
    minute_temp = (tv.tv_sec - hour_temp * 3600) / 60;
    second_temp = tv.tv_sec - hour_temp * 3600 - minute_temp * 60;
    m_second_temp = tv.tv_usec / 1000;

  } else if (tv.tv_sec >= 60) {
    minute_temp = tv.tv_sec / 60;
    second_temp = tv.tv_sec - minute_temp;
    m_second_temp = tv.tv_usec / 1000;
    hour_temp = 0;
  } else {
    second_temp = tv.tv_sec - minute_temp;
    m_second_temp = tv.tv_usec / 1000;

    hour_temp = 0;
    minute_temp = 0;
  }

  hour_s = num2str(hour_temp2);
  minute_s = num2str(minute_temp);
  second_s = num2str(second_temp);
  m_second_s = num2str(m_second_temp);

  string_time = hour_s + "_" + minute_s + "_" + second_s + "." + m_second_s;

  return string_time;
} // end GetTime