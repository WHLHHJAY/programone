#ifndef __LIB_EMUC_H__
#define __LIB_EMUC_H__ 

/*------------------------------------------------------------------------------------------------------------*/
#define MAX_COM_PORT    16
#define MAX_BUF         512

#define ID_LEN          4
#define DATA_LEN        8   
#define VER_LEN         16

#define DIM(var, type)  (sizeof(var)) / sizeof(type)

#define BOOL    bool
#define TRUE    true
#define FALSE   false

#define DATA_LEN_ERR     12
#define TIME_CHAR_NUM    13
#define CAN_NUM          2


/*------------------------------------------------------------------------------------------------------------*/
enum
{
EMUC_DIS_ALL = 0,
EMUC_EE_ERR =1,
EMUC_BUS_ERR =2,
EMUC_EN_ALL = 255
};

enum
{
    EMUC_INACTIVE = 0,
    EMUC_ACTIVE = 1
};

enum
{
    EMUC_BAUDRATE_100K = 4,
    EMUC_BAUDRATE_125K =5,
    EMUC_BAUDRATE_250K =6,
    EMUC_BAUDRATE_500K =7,
    EMUC_BAUDRATE_800K =8,
    EMUC_BAUDRATE_1M =9
};

typedef struct
{
    int CAN_port;
    int id_type;
    int rtr;
    int dlc;
    int msg_type;
    char recv_time[TIME_CHAR_NUM];/* e.g., 15:30:58:789 (h:m:s:ms) */
    unsigned int id;
    unsigned char data[DATA_LEN];
    unsigned char data_err[CAN_NUM][DATA_LEN_ERR];

} DATA_INFO;

typedef struct
{
char fw[VER_LEN];
char api[VER_LEN];
char model[VER_LEN];
} VER_INFO;

typedef struct
{
    unsigned int cnt;
    unsigned int interval; /* [ms] */
    DATA_INFO *can_frame_info;
} NON_BLOCK_INFO;

typedef struct
{
    int CAN_port;
    int flt_type;
    unsigned int flt_id;
    unsigned int mask;
} FILTER_INFO;
/*------------------------------------------------------------------------------------------------------------*/
extern int  EMUCOpenDevice(int port);

extern int  EMUCResetCAN(int com_port);
extern int  EMUCReceive (int com_port, DATA_INFO *can_frame_info);
extern int  EMUCSend (int com_port, DATA_INFO *can_frame_info);


extern int EMUCCloseDevice     (int com_port);
extern int EMUCClearFilter     (int com_port, int CAN_port);
extern int EMUCSetErrorType    (int com_port, int err_type);
extern int EMUCShowVer         (int com_port, VER_INFO *ver_info);
extern int EMUCInitCAN         (int com_port, int CAN1_sts,  int CAN2_sts);
extern int EMUCSetBaudRate     (int com_port, int CAN1_baud, int CAN2_baud);
extern int EMUCSetMode         (int com_port, int CAN1_mode, int CAN2_mode);
extern int EMUCReceiveNonblock (int com_port, NON_BLOCK_INFO *non_block_info);
extern int EMUCOpenSocketCAN   (int com_port);

extern int EMUCEnableSendQueue (int com_port, bool is_enable, unsigned int queue_size);
extern int EMUCSetFilter       (int com_port, FILTER_INFO *filter_info);
#endif
