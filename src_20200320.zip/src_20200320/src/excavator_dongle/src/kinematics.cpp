#include "kinematics.hpp"

#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>

extern bool verbose_mode;
using namespace boost::property_tree;

namespace accontrol_kinematics {

// switch among 3 different excavators
// using namespace excavator_control;
// using namespace excavator1300;
// using namespace excavator950;

void kinematics::ParamInit() {
  ptree pt;

  std::stringstream ss_t;
  ss_t << cfg_file_path_ << "/config/config.xml";
  read_xml(ss_t.str(), pt);     //读入一个xml文件

  ID_ID = pt.get<int>("param.ID");  //动臂相对回转关节X方向的偏移
  kBiasX = pt.get<double>("param.X0");  //动臂相对回转关节X方向的偏移
  kBiasY = pt.get<double>("param.Y0");  //动臂相对回转关节Y方向的偏移
  kBiasZ = pt.get<double>("param.Z0");  //动臂相对回转关节Z方向的偏移

  kBoomALen = pt.get<double>("param.a2");  //动臂和斗杆之间连杆长度
  kStickALen = pt.get<double>("param.a3");  //斗杆和铲斗之间连杆长度
  kBucketALen = pt.get<double>("param.a4");  //铲斗旋转中心到铲斗齿间连杆长度

  kL1 = pt.get<double>("param.L1");  //四连杆机构KL1
  kL2 = pt.get<double>("param.L2");  //四连杆机构KL2
  kL3 = pt.get<double>("param.L3");  //四连杆机构KL3
  kL4 = pt.get<double>("param.L4");  //四连杆机构KL4

  kTheta1 = pt.get<double>("param.kTheta1");  //四连杆机构连杆3和m_dLinkLengh[2]连杆的夹角
  kTheta2 = pt.get<double>("param.kTheta2");  //四连杆机构连杆2和m_dLinkLengh[1]连杆的夹角

  kThetaStick = pt.get<double>("param.kThetaStick");
  kThetaBoom = pt.get<double>("param.kThetaBoom");
}

void kinematics::fkC2W() {
  double boom_converted = posC[boom] + 17.3;
  double stick_converted = 180 - boom_converted - (posC[stick] - 17.3);
  double bucket_converted = 180 + stick_converted - posC[bucket];
  stick_converted = -stick_converted;
  bucket_converted = -bucket_converted;

  posInter[swing][x] = 0;
  posInter[swing][y] = 0;
  posInter[swing][z] = 0;

  posInter[boom][x] = posInter[swing][x] + kBoomALen * cos(deg2rad(boom_converted));
  posInter[boom][y] = posInter[swing][y];
  posInter[boom][z] = posInter[swing][z] + kBoomALen * sin(deg2rad(boom_converted));

  posInter[stick][x] = posInter[boom][x] + kStickALen * cos(deg2rad(stick_converted));
  posInter[stick][y] = posInter[boom][y];
  posInter[stick][z] = posInter[boom][z] + kStickALen * sin(deg2rad(stick_converted));

  posInter[bucket][x] = posInter[stick][x] + kBucketALen * cos(deg2rad(bucket_converted));
  posInter[bucket][y] = posInter[stick][y];
  posInter[bucket][z] = posInter[stick][z] + kBucketALen * sin(deg2rad(bucket_converted));

  for (int i = 0; i < 4; i++) {
    posW[i][x] = posInter[i][x] * cos(deg2rad(posC[swing])) + kBiasX;
    posW[i][y] = posInter[i][x] * sin(deg2rad(posC[swing])) + kBiasY;
    posW[i][z] = posInter[i][z] + kBiasZ;
    posInter[i][x] += kBiasX;
    posInter[i][y] += kBiasY;
    posInter[i][z] += kBiasZ;
  }
}

void kinematics::fkL2C() {
  // all cylinder extension converted to joint angles
  bool greater_than_pi = false;
  posC[boom] = ForwardKinematicsBoom(posL[boom]);
  posC[stick] = ForwardKinematicsStick(posL[stick]);
  posC[bucket] = ForwardKinematicsBucket(posL[bucket]);
}

void kinematics::fkL2C(const int &joint_id) {
  bool greater_than_pi = false;
  switch (joint_id) {
    case 1:
      posC[boom] = ForwardKinematicsBoom(posL[boom]);
      break;
    case 2:
      posC[stick] = ForwardKinematicsStick(posL[stick]);
      break;
    case 3:
      posC[bucket] = ForwardKinematicsBucket(posL[bucket]);
      break;

    default:
      break;
  }
}

void kinematics::ikC2L(const int &joint_id) {
  bool greater_than_pi = false;
  switch (joint_id) {
    case 1:
      posL[boom] = InverseKinematicsBoom(posC[boom]);
      break;
    case 2:
      posL[stick] = InverseKinematicsStick(posC[stick]);
      break;
    case 3:
      posL[bucket] = InverseKinematicsBucket(posC[bucket]);
      break;

    default:
      break;
  }
}

void kinematics::ikC2L() {
  // all joint angles converted to cylinder extension
  bool greater_than_pi = false;
  posL[boom] = InverseKinematicsBoom(posC[boom]);
  posL[stick] = InverseKinematicsStick(posC[stick]);
  posL[bucket] = InverseKinematicsBucket(posC[bucket]);
}

void kinematics::ikW2C() {
  // not implemented yet
  ;
}

void kinematics::GetEnsPose() {
  // kinematics::RawAngleConversion has to be called before setPoseC
  double boom_converted = posC[boom];
  double stick_converted = posC[stick];
  double bucket_converted = posC[bucket];

  posInter[swing][x] = 0;
  posInter[swing][y] = 0;
  posInter[swing][z] = 0;

  posInter[boom][x] = posInter[swing][x] + kBoomALen * cos(deg2rad(boom_converted));
  posInter[boom][y] = posInter[swing][y];
  posInter[boom][z] = posInter[swing][z] + kBoomALen * sin(deg2rad(boom_converted));

  posInter[stick][x] = posInter[boom][x] + kStickALen * cos(deg2rad(stick_converted));
  posInter[stick][y] = posInter[boom][y];
  posInter[stick][z] = posInter[boom][z] + kStickALen * sin(deg2rad(stick_converted));

  posInter[bucket][x] = posInter[stick][x] + kBucketALen * cos(deg2rad(bucket_converted));
  posInter[bucket][y] = posInter[stick][y];
  posInter[bucket][z] = posInter[stick][z] + kBucketALen * sin(deg2rad(bucket_converted));

  double heading = center_ens_frame[0];
  for (int i = 0; i < 4; i++) {
    posW[i][x] = posInter[i][x] * cos(heading) - posInter[i][y] * sin(heading) + kBiasX + center_ens_frame[1];
    posW[i][y] = posInter[i][x] * sin(heading) + posInter[i][y] * cos(heading) + kBiasY + center_ens_frame[2];
    posW[i][z] = posInter[i][z] + kBiasZ + center_ens_frame[3];
  }
  pos_ens_frame[0] =
          posInter[bucket][x] * cos(heading) - posInter[bucket][y] * sin(heading) + kBiasX + center_ens_frame[1];
  pos_ens_frame[1] =
          posInter[bucket][x] * sin(heading) + posInter[bucket][y] * cos(heading) + kBiasY + center_ens_frame[2];
  pos_ens_frame[2] = posInter[bucket][z] + kBiasZ + center_ens_frame[3];
}

inline void CheckTruncationErrors(double &temp_storage) {
  // This temp_storage might be slightly larger(smaller) than 1(-1) due to truncation errors.
  // And even the smallest out of range will cause acos/asin return a nan.
  // So check for truncation errors every time before using math functions.
  if (temp_storage > 1) {
    temp_storage = 1;
  }
  if (temp_storage < -1) {
    temp_storage = -1;
  }
}

// The following six functions are fitted from actual data.
// However they are only valid within the actual range of joints and cylinders.
// So don't expect them to give good results in out-of-range simulations.
double kinematics::ForwardKinematicsBoom(const double &len_boom_) {
  double square_len = len_boom_ * len_boom_;
  return 1.3253e-5 * square_len + 0.0203 * len_boom_ - 35.3264;
}

double kinematics::InverseKinematicsBoom(const double &angle_boom_) {
  double square_angle = angle_boom_ * angle_boom_;
  return -0.0716 * square_angle + 20.3 * angle_boom_ + 1038.1;
}

double kinematics::ForwardKinematicsStick(const double &len_stick_) {
  double square_len = len_stick_ * len_stick_;
  double cube_len = square_len * len_stick_;
  return -1.1911e-8 * cube_len + 2.6711e-5 * square_len - 0.0731 * len_stick_ + 161.8737;
}

double kinematics::InverseKinematicsStick(const double &angle_stick_) {
  double square_angle = angle_stick_ * angle_stick_;
  double cube_angle = square_angle * angle_stick_;
  return 7.0612e-4 * cube_angle - 0.2492 * square_angle + 10.9722 * angle_stick_ + 1750.7;
}

double kinematics::ForwardKinematicsBucket(const double &len_bucket_) {
  double square_len = len_bucket_ * len_bucket_;
  double cube_len = square_len * len_bucket_;
  return -1.5525e-8 * cube_len + 3.8279e-5 * square_len - 0.089 * len_bucket_ + 218.115;
}

double kinematics::InverseKinematicsBucket(const double &angle_bucket_) {
  double square_angle = angle_bucket_ * angle_bucket_;
  double cube_angle = square_angle * angle_bucket_;
  return 8.4860e-4 * cube_angle - 0.3918 * square_angle + 42.7461 * angle_bucket_ + 558.5349;
}

void
kinematics::P1CFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // WARNING: THE CONTROL FRAME OF STICK INCLUDES THE SHARP ANGLE OF BOOM'S STRUCTURE (17.3 DEG)
  float temp_boom = boom_angle;
  float temp_stick = stick_angle;
  swing_angle = -swing_angle;// swing
  boom_angle = boom_angle - 17.3; // boom
  stick_angle = 180 - (stick_angle - 17.3) - temp_boom; // stick
  bucket_angle = 180 + temp_stick - bucket_angle; // bucket

  if (swing_angle < 0) {
    swing_angle = swing_angle + 360;
  }

}

void
kinematics::P2CFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // the trend should be the same now, don't care
  swing_angle = -swing_angle;
  boom_angle = -boom_angle; // in P2, boom is negative when it is above horizontal line
  boom_angle = boom_angle - 17.3;
  stick_angle = 180 - stick_angle + 17.3;
  bucket_angle = 180 - bucket_angle;
}

void
kinematics::CP2FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  swing_angle = -swing_angle;
  boom_angle = boom_angle + 17.3;
  boom_angle = -boom_angle;
  stick_angle = 180 - stick_angle + 17.3;
  bucket_angle = 180 - bucket_angle;
}

void
kinematics::CP1FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  swing_angle = -swing_angle;
  boom_angle = boom_angle + 17.3;
  stick_angle = 180 - boom_angle - (stick_angle - 17.3);
  bucket_angle = 180 + stick_angle - bucket_angle;
  if (swing_angle < 0) {
    swing_angle = swing_angle + 360;
  }
}

void
kinematics::P1P2FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // From planner frame v1.0 to planner frame v2.0
  // planner frame v2.0 is very close to control frame, so convert to control frame first

  // NOW IN P1 FRAME, to CONTROL FRAME.
  P1CFrameConversion(swing_angle, boom_angle, stick_angle, bucket_angle);

  // NOW IN CONTROL FRAME, to P2 FRAME.
  CP2FrameConversion(swing_angle, boom_angle, stick_angle, bucket_angle);
  // CONVERSION COMPLETED, NOW IN P2 FRAME

}

void
kinematics::P2P1FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // From planner frame v2.0 to planner frame v1.0
  // inverse operation of the previous function

  // NOW IN P2 FRAME, to CONTROL FRAME
  P2CFrameConversion(swing_angle, boom_angle, stick_angle, bucket_angle);

  // NOW IN CONTROL FRAME, to P1 FRAME
  CP1FrameConversion(swing_angle, boom_angle, stick_angle, bucket_angle);
}

void
kinematics::SensorCFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // read angles measurement, convert to configuration space
  // There are 2 typical schemes, the only difference is the position of boom angle's sensor.
  // 1. parallel to the line between the boom joint and the stick joint
  //    boom and stick are unchanged
  // kL1~kL4 are lengths of the four-bar linkage
  double l1_2 = kL1 * kL1 + kL2 * kL2 - 2 * kL1 * kL2 * std::cos(deg2rad(bucket_angle - stick_angle));
  double l1 = std::sqrt(l1_2);
  double cos_theta1 = (kL2 * kL2 + l1 * l1 - kL1 * kL1) / (2 * kL2 * l1);
  double cos_theta2 = (kL3 * kL3 + l1 * l1 - kL4 * kL4) / (2 * kL3 * l1);
  // truncation error might cause out of range cosines.
  if (cos_theta1 > 1) {
    cos_theta1 = 1;
  }
  if (cos_theta1 < -1) {
    cos_theta1 = -1;
  }
  if (cos_theta2 > 1) {
    cos_theta2 = 1;
  }
  if (cos_theta2 < -1) {
    cos_theta2 = -1;
  }
  double a1 = rad2deg(std::acos(cos_theta1));
  double a2 = rad2deg(std::acos(cos_theta2));
  double a3 = a1 + a2;
  // this is the angle between the stick and bucket
  bucket_angle = 360 - kTheta1 - kTheta2 - a3;
  // the angle between horizon and the bucket line
  bucket_angle = stick_angle + bucket_angle - 180;
}

void RollCompensation(double &boom_angle, double &stick_angle, double &bucket_angle, double roll) {
  // inputs and outputs are in degrees
  // first convert everything to radians
  double joint_angles[3];
  joint_angles[0] = boom_angle * M_PI / 180;
  joint_angles[1] = stick_angle * M_PI / 180;
  joint_angles[2] = bucket_angle * M_PI / 180;
  roll = std::abs(roll * M_PI / 180);

  // theta' = atan(1/sqrt(1/tan(theta)^2 + tan(roll)^2))
  // this formula is valid for theta in (-pi/2, pi/2), pi/2 is a sigular value for atan
  // and it is very tricky, I just ignore theta outside this interval.
  for (int i = 0; i < 3; ++i) {
    if (joint_angles[i] == 0 || joint_angles[i] >= M_PI / 2) {
      continue;
    }
  }
}

void
kinematics::RawAngleConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // This part applies to the 950 excavator only
  if (ID_ID == 950) {
    // all three sensors are installed in the opposite direction
    // that is, we get +/-180 around horizon.
    if (boom_angle > 0) {
      boom_angle = 180 - boom_angle;
    } else {
      boom_angle = -180 - boom_angle;
    }
    if (stick_angle > 0) {
      stick_angle = 180 - stick_angle;
    } else {
      stick_angle = -180 - stick_angle;
    }
    if (bucket_angle > 0) {
      bucket_angle = 180 - bucket_angle;
    } else {
      bucket_angle = -180 - bucket_angle;
    }

    if (verbose_mode) {
      std::cout << "Inverted raw data" << std::endl;
      std::cout << "boom: " << boom_angle << ", stick:" << stick_angle << ", bucket:" << bucket_angle << std::endl;
    }

  }

  // For the 1300
  if (ID_ID == 1300) {
    if (bucket_angle >= 0) {
      bucket_angle = 180 - bucket_angle;
    }
    if (bucket_angle < 0) {
      bucket_angle = -180 - bucket_angle;
    }
    if (verbose_mode) {
      std::cout << "Inverted raw data" << std::endl;
      std::cout << "Bucket " << bucket_angle << std::endl;
    }
  }
  // boom
  boom_angle = boom_angle + kThetaBoom;

  // stick
  stick_angle = stick_angle + kThetaStick;
  // bucket
  // Inputs: swing and boom are irrelavent; stick_angle should be the angle between horizon and joint-linking line
  //		   bucket is the raw measurement, sensor installed on the input link of the four-bar linkage
  double l1_2 = kL1 * kL1 + kL2 * kL2 - 2 * kL1 * kL2 * std::cos(deg2rad(bucket_angle - stick_angle + kTheta2));
  double l1 = std::sqrt(l1_2);
  double cos_theta1 = (kL2 * kL2 + l1 * l1 - kL1 * kL1) / (2 * kL2 * l1);
  double cos_theta2 = (kL3 * kL3 + l1 * l1 - kL4 * kL4) / (2 * kL3 * l1);
  if (cos_theta1 > 1) {
    cos_theta1 = 1;
  }
  if (cos_theta1 < -1) {
    cos_theta1 = -1;
  }
  if (cos_theta2 > 1) {
    cos_theta2 = 1;
  }
  if (cos_theta2 < -1) {
    cos_theta2 = -1;
  }
  double a1 = rad2deg(std::acos(cos_theta1));
  double a2 = rad2deg(std::acos(cos_theta2));
  double a3 = a1 + a2;
  bucket_angle = 360 - kTheta1 - kTheta2 - a3;
  bucket_angle = stick_angle + bucket_angle - 180;
}

void kinematics::GetAngleToSend(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle) {
  // kinematics::RawAngleConversion has to be called before setPoseC
  double boom_converted = posC[boom];
  double stick_converted = posC[stick];
  double bucket_converted = posC[bucket];

  swing_angle = 0;
  // boom sensor on the distal part -> joints-connecting line (boom_converted) -> angle of the proximal part
  boom_angle = boom_converted + kThetaBoom; // This kThetaBoom might not be exact
  boom_angle = 90 - boom_angle;
  boom_angle = -boom_angle; // This is the final angle to be sent

  stick_angle = stick_converted;

  bucket_angle = (bucket_converted - stick_converted);

}

} // end namespace accontrol_kinematics