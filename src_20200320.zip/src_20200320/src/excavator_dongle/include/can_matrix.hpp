#ifndef CAN_MATRIX_H
#define CAN_MATRIX_H

/***********control message id******************/
#define EXCAVATOR_ARM_CTR      						0x18FF1C02

#define can_mode       1
#define can_rtr        0

#define can_channel    3
#define CAN1_mode      0
#define CAN2_mode      0

#define can_rtr        0
#define port           24    //ttyACM0

#define EMUC_CAN_1      0
#define EMUC_CAN_2      1

#define EMUC_DATA_TYPE    0
#define EMUC_EEERR_TYPE   1
#define EMUC_BUSERR_TYPE  2

#define EMUC_SID      		1
#define EMUC_EID      		2

#define EMUC_DIS_RTR      0
#define EMUC_EN_RTR       1

#define  FIFTER_CAN_1     0
#define  FIFTER_TYPE      2
#define  FIFTER_ID        0x18FF0000
#define  FIFTER_MASK      0x1FFF0000 

typedef  union{

		unsigned char bytestate[8];
		/*struct
		{
			unsigned char	handle_control         		:1;			
			unsigned char	data0_unsued1_7    	   		:7;

			unsigned char	setangle_boom_cmd      		:8;
			unsigned char	setangle_stick_cmd_H      	:8;
			unsigned char	setangle_stick_cmd_L      	:8;
			unsigned char	setangle_bucket_cmd_H      	:8;
			unsigned char	setangle_bucket_cmd_L      	:8;
			unsigned char	setangle_swing_cmd_H      	:8;
			unsigned char	setangle_swing_cmd_L      	:8;		

		}bits; */
		struct{
			//unsigned char controlFlag;

			unsigned char SwingHpwm;
			unsigned char SwingLpwm;
			unsigned char BoomHpwm;
			unsigned char BoomLpwm;
			unsigned char StickHpwm;
			unsigned char StickLpwm;
			unsigned char BucketHpwm;
			unsigned char BucketLpwm;
		}bits;
} Send_Message_excavator_arm_Temp;


#endif


