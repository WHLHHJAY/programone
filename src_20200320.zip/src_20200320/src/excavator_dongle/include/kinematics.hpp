#ifndef ACCONTROL_KINEMATICS
#define ACCONTROL_KINEMATICS

#include <cmath>
#include <iostream>

/*
    The kinematics is more and more a pile of shit. 
    Writing another version from scratch might be easier than reconstruction
*/

namespace accontrol_kinematics {

/*   enum possible_types {TYPE1300 = 1300, TYPE950 = 950, TYPE130 = 130};

   namespace excavator1300{
       const int backhoe_type = TYPE1300;

       const double kBiasX = 450;
       const double kBiasY = 0;
       const double kBiasZ = 3442.5;
       const double kBoomALen = 7800;
       const double kStickALen = 3399.8;
       const double kBucketALen = 2716.3;
       // constants for sensor-control frame conversion, SHOULD BE CHANGED
       const double kL1 = 1920;
       const double kL2 = 590.3;
       const double kL3 = 950;
       const double kL4 = 1028;
       const double kTheta1 = 104.6;
       const double kTheta2 = 8.823;


       // angle between the upper edge of the stick and the joint-linking line, measured
       // the sensor is mounted parallel to joint-linking line
       const double kThetaStick = 0;


       // angle between the upper edge of the distal part of boom and the joint-linking line
       // the sensor is mounted parallel to the joint-linking line
       const double kThetaBoom = 0;
   }
   */
/*
 namespace excavator950{
     const int backhoe_type = TYPE950;

     const double kBiasX = 220;
     const double kBiasY = 0;
     const double kBiasZ = 2853.7;
     const double kBoomALen = 7250;
     const double kStickALen = 2925;
     const double kBucketALen = 2610;


     // length of the four-bar linkage
     const double kL1 = 920; // input link
     const double kL2 = 580; // ground link
     const double kL3 = 700; // output link
     const double kL4 = 830; // floating link
     // angle between the output link and the bucket side edge, measured
     const double kTheta1 = 86;
     // angle between the ground link and the joint-linking line, UNKNOW, TO BE MEASURED
     const double kTheta2 = 5;


     // angle between the upper edge of the stick and the joint-linking line, measured
     // the sensor is mounted parallel to the upper edge
     const double kThetaStick = 12.5;

     // angle between the upper edge of the distal part of boom and the joint-linking line, TO BE MEASURED
     // the sensor is mounted parallel to the upper edge
     const double kThetaBoom = 22.8; // FICTION DATA
 }
 */

// namespace excavator130{
// const int backhoe_type = TYPE130;
// 
// const double kBiasX = 120;// [mm]
// const double kBiasY = -137;
// const double kBiasZ = 579;
// const double kBoomALen = 4600;
// const double kStickALen = 2109;
// const double kBucketALen = 1235;
// // constants for sensor-control frame conversion
// const double kL1 = 510;
// const double kL2 = 350;
// const double kL3 = 388.4;
// const double kL4 = 450;
// const double kTheta1 = 101;
// const double kTheta2 = 5;
// const double kThetaBoom = 17.3;
// const double kThetaStick = 17.3;
// }

class kinematics {
  enum joints { swing = 0, boom = 1, stick = 2, bucket = 3 };
  enum xyz { x = 0, y = 1, z = 2 };
  struct point3d {
    double x;
    double y;
    double z;
  };
  struct point4d {
    double swing;
    double boom;
    double stick;
    double bucket;
  };
  // not sure which namespace lies M_PI...
  const double kPi = 3.1415926;

public:
  // [joints][x/y/x] positions of proximal axis in vehicle frame (swing rotation included)
  double posW[4][3];
  // positions of proximal axis in upper cabin frame, i.e. angleSwing is always 0.
  double posInter[4][3];
  // joint angles in configuration space
  double posC[4];
  // cylinder lengths
  double posL[4];
  // bucket tip position (x, y, z), in the global North-East-Sky frame.
  double pos_ens_frame[3];
  // rotation center position (heading, x, y, z), in the global North-East-Sky frame
  double center_ens_frame[4];


//param
  int ID_ID;
  double kBiasX;
  double kBiasY;
  double kBiasZ;
  double kBoomALen;
  double kStickALen;
  double kBucketALen;
  /* Constant values for bucket calculation */
  // length of the four-bar linkage
  double kL1; // input link
  double kL2; // ground link
  double kL3; // output link
  double kL4; // floating link
  // angle between the output link and the bucket side edge, measured
  double kTheta1;
  // angle between the ground link and the joint-linking line, UNKNOW, TO BE MEASURED
  double kTheta2;

  double kThetaStick;
  double kThetaBoom; // FICTION DATA
  //param

  // constructor
  kinematics() {
    ParamInit();
    for (int i = 0; i < 4; i++) {
      posInter[i][x] = 0;
      posInter[i][y] = 0;
      posInter[i][z] = 0;
      posW[i][x] = 0;
      posW[i][y] = 0;
      posW[i][z] = 0;
      posC[i] = 0;
      posL[i] = 0;
      center_ens_frame[i] = 0;
      if (i < 3) {
        pos_ens_frame[i] = 0;
      }
    }
  };

  kinematics(std::string cfg_path) : cfg_file_path_(cfg_path) {
    ParamInit();
    for (int i = 0; i < 4; i++) {
      posInter[i][x] = 0;
      posInter[i][y] = 0;
      posInter[i][z] = 0;
      posW[i][x] = 0;
      posW[i][y] = 0;
      posW[i][z] = 0;
      posC[i] = 0;
      posL[i] = 0;
      center_ens_frame[i] = 0;
      if (i < 3) {
        pos_ens_frame[i] = 0;
      }
    }
  };

  // input: (heading of the vehicle, x, y, z of the rotation center in the East-North-Sky frame)
  void SetCenterEnsFrame(const double *center_pose, const int len_vals = 4) {
    for (int i = 0; i < len_vals; i++) {
      center_ens_frame[i] = center_pose[i];
    }
  }

  // forward kinematics, calculate the position of the bucket tip in the east-north-sky frame
  void GetEnsPose();

  void setPosW(const double &px, const double &py, const double &pz) {
    posW[3][x] = px;
    posW[3][y] = py;
    posW[3][z] = pz;
  }

  void setPosC(const double &swingAng, const double &boomAng, const double &stickAng, const double &bucketAng) {
    // convert joint angles in control frame to kinematic frame
    // inputs: actangleXXX
    posC[swing] = swingAng;
    posC[boom] = boomAng;
    posC[stick] = stickAng;
    posC[bucket] = bucketAng;
  }

  void setPosL(const double &len1BoomC, const double &len2BoomC, const double &lenStickC, const double &lenBucketC) {
    posL[boom] = (len1BoomC + len2BoomC) / 2;
    posL[stick] = lenStickC;
    posL[bucket] = lenBucketC;
    posL[swing] = 0;
  }

  void getPosW(double &px, double &py, double &pz) {
    px = posW[3][x];
    py = posW[3][y];
    pz = posW[3][z];
  }

  void getPosC(double &swingAng, double &boomAng, double &stickAng, double &bucketAng) {
    swingAng = posC[swing];
    boomAng = posC[boom];
    stickAng = posC[stick];
    bucketAng = posC[bucket];
  }

  void getPosL(double &lenBoom, double &lenStick, double &lenBucket) {
    lenBoom = posL[boom];
    lenStick = posL[stick];
    lenBucket = posL[bucket];
  }


  void ParamInit();

  // Configuration space (joint angles) to work space (x-y-z)
  void fkC2W();

  // Cylinder extension (lenXXX) to Configuration space
  void fkL2C();

  void fkL2C(const int &joint_id);

  // Work space to Configuration space
  void ikW2C();

  // Configuration space to cylinder extension
  void ikC2L();

  void ikC2L(const int &joint_id);

  // joint-cylinder fk and ik for each joint
  double ForwardKinematicsBucket(const double &len_bucket);

  double InverseKinematicsBucket(const double &angle_bucket);

  double ForwardKinematicsStick(const double &len_stick);

  double InverseKinematicsStick(const double &angle_stick);

  double ForwardKinematicsBoom(const double &len_boom);

  double InverseKinematicsBoom(const double &angle_boom);

  // Conversions with 2 different planner frame (P1 <---> P2) <-----> control frame
  // Don't ask me why there are two planner frames, it's not my desicision
  void P1CFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void P2CFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void CP1FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void CP2FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void P1P2FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void P2P1FrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void SensorCFrameConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void RawAngleConversion(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  void GetAngleToSend(double &swing_angle, double &boom_angle, double &stick_angle, double &bucket_angle);

  inline double deg2rad(double deg_) {
    return deg_ * kPi / 180;
  }

  inline double rad2deg(double rad_) {
    return rad_ * 180 / kPi;
  }

private:
  std::string cfg_file_path_ = "";
};

// using namespace excavator950;
//using namespace excavator1300;
// using namespace excavator130;

} // end namespace accontrol_kinematics


#endif