#include <ros/ros.h>
#include <sensor_msgs/NavSatFix.h>

double gLatitudeDeg = 0;
double gLongitudeDeg = 0;
bool gDataReady = false;

void GpsCallback(const sensor_msgs::NavSatFix::ConstPtr &msg) {
  gLatitudeDeg = msg->latitude;
  gLongitudeDeg = msg->longitude;
  gDataReady = true;
}

int main(int argc, char **argv) {
  int ros_rate;
  if (argc < 2) {
    std::cout << "loop rate unset, used default value 100 Hz" << std::endl;
    ros_rate = 100;
  } else {
    ros_rate = atoi(argv[1]);
  }
  ros::init(argc, argv, "deg2dms");
  ros::NodeHandle converter_handle;

  ros::Rate loop_rate(ros_rate);

  ros::Subscriber deg_sub = converter_handle.subscribe("/gps/bucket/fix", 1, GpsCallback);

  while (ros::ok()) {
    ros::spinOnce();

    if (!gDataReady) {
      loop_rate.sleep();
      continue;
    }
    double latitude_deg = gLatitudeDeg;
    double longitude_deg = gLongitudeDeg;

    int lat_d = static_cast<int>(latitude_deg);
    latitude_deg -= lat_d;
    latitude_deg *= 60;
    int lat_m = static_cast<int>(latitude_deg);
    latitude_deg -= lat_m;
    latitude_deg *= 60;
    double lat_s = latitude_deg;

    int lon_d = static_cast<int>(longitude_deg);
    longitude_deg -= lon_d;
    longitude_deg *= 60;
    int lon_m = static_cast<int>(longitude_deg);
    longitude_deg -= lon_m;
    longitude_deg *= 60;
    double lon_s = longitude_deg;

    ROS_INFO("In deg: %f E, %f N", gLongitudeDeg, gLatitudeDeg);
    ROS_INFO("In dms: %d\370%d\'%3.8f\"E, %d\370%d\'%3.8f\"N", lon_d, lon_m, lon_s, lat_d, lat_m, lat_s);

    loop_rate.sleep();
  }

  return 0;
}